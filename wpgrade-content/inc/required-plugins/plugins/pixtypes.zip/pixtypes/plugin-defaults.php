<?php return array
	(
		// Default article settings
		'enable_portfolio' => true,

	#
	# "Technical Stuff" fields
	#

		'portfolio_single_item_label' => 'Proiect',
		'portfolio_multiple_items_label' => 'Proiects',

		'portfolio_change_single_item_slug' => true,
		'portfolio_new_single_item_slug' => 'portfolio',

		'portfolio_change_archive_slug' => false,
		'portfolio_new_archive_slug' => '',

		'portfolio_use_tags' => true

	); # config
