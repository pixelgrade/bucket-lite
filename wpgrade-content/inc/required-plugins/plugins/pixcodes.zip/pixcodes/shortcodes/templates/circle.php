<?php
echo '<input class="dial" type="text" value="'.$value.'" data-text="'.$title.'" data-fgcolor="'.$color.'" data-angleoffset="'.$offset.'" />';