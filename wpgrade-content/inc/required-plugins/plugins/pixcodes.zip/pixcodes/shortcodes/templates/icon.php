<?php
echo '<i class="shc '.$type.' '.$size.' ' .$class. ' icon-'.$name.'"></i>';