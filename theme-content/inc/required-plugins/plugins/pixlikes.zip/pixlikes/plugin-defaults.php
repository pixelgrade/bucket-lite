<?php return array
	(

	# Hidden fields

//		'settings_saved_once' => '0',

	# "Post Types" fields
	'show_on_post' => false,
	'show_on_page' => false,
	'show_on_hompage' => false,
	'show_on_archive' => false,
	'like_action' => 'hover',
	'hover_time' => 1000,
	'free_votes' => false,
	'load_likes_with_ajax' => false,
	); # config
