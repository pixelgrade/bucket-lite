<?php return array
	(

	# Hidden fields

//		'settings_saved_once' => '0',

	# "Post Types" fields
	'show_on_post' => false,
	'show_on_page' => false,
	'like_action' => 'hover',
	'hover_time' => 1000,
	'free_votes' => false,
	); # config
