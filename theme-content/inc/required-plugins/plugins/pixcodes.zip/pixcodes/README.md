=== PixCodes ===

WordPress shortcodes plugin everywhere. Loaded with shortcodes, awesomeness and more.

=== # ===

~Current Version:2.0.1~

=== # ===

Tags: wordpress, shortcodes, plugin
Requires at least: 3.5.1
Tested up to: 3.6.1
Stable tag: 2.0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

=== # ===

