=== PixLikes ===

WordPress shortcodes plugin everywhere. Loaded with shortcodes, awesomeness and more.

==================

~Current Version:2.0.0~

==================

Shortcodes Generator for wpGrade Wordpress Themes
