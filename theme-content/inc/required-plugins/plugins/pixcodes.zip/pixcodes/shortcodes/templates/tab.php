<title><?php echo do_shortcode( $title ); ?></title>
<icon><?php echo $icon ?></icon>
<body><?php echo do_shortcode( $content ); ?></body>