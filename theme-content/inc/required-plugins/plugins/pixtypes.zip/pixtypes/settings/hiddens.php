<?php return array
	(
		'type' => 'group',
		'options' => array
			(
				'settings_saved_once' => array
					(
						'default' => '0',
						'value' => '1',
						'type' => 'hidden',
					),
			)
	); # config