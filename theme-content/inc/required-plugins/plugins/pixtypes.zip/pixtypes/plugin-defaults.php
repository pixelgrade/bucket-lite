<?php return array
	(

	# Hidden fields

		'settings_saved_once' => '0',

	# "Post Types" fields
	'enable_portfolio' => true,

		'portfolio_single_item_label' => 'Project',
		'portfolio_multiple_items_label' => 'Projects',

		'portfolio_change_single_item_slug' => true,
		'portfolio_new_single_item_slug' => 'portfolio',

		'portfolio_change_archive_slug' => false,
		'portfolio_new_archive_slug' => '',

//		'portfolio_use_tags' => false,

	'enable_gallery' => true,

	# "Taxonomies" fields
		'enable_portfolio_categories' => true,
			'portfolio_categories_change_archive_slug' => false,
			'portfolio_categories_new_archive_slug' => '',
		'enable_gallery_categories' => true

	); # config
