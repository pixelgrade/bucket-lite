<?php 

echo '<i class="pixcode  pixcode--icon  icon-'.$name.'  '.$type.'  '.$size.'  '.$class.'"></i>';