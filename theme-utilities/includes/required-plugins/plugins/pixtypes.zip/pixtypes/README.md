=== PixTypes ===

WordPress plugin for managing custom post types and custom meta boxes.

=== # ===

~Current Version:1.1.9~

=== # ===

Tags: wordpress, cpt, metaboxes, custom post types, plugin
Requires at least: 3.5.1
Tested up to: 3.6.1
Stable tag: 1.0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

=== # ===